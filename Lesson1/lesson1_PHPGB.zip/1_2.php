<?php
$name = readline('Как вас зовут?. ');
$age = readline('Сколько вам лет?. ');

$result = "Вас зовут $name, вам $age лет";

echo $result;
?>